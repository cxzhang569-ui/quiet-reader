#!/bin/sh
set -eu
TASK_ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
if [ -n "${JAVA_HOME:-}" ]; then JDK_BIN="$JAVA_HOME/bin/"; else JDK_BIN=; fi
"${JDK_BIN}javac" -version >/dev/null 2>&1 || { echo '需要 JDK 17 或以上版本才能运行解析器测试。' >&2; exit 1; }
TASK_BUILD=$(mktemp -d)
trap 'rm -rf "$TASK_BUILD"' EXIT HUP INT TERM
"${JDK_BIN}javac" -encoding UTF-8 -d "$TASK_BUILD" \
    "$TASK_ROOT/app/src/main/java/cn/local/quietreader/EpubBook.java" "$TASK_ROOT/tests/ParserChecks.java"
"${JDK_BIN}java" -cp "$TASK_BUILD" cn.local.quietreader.ParserChecks
