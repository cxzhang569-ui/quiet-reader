#!/bin/sh
# Offline fallback for this dependency-free app, using installed official SDK tools.
set -eu
TASK_ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
JAVA_HOME=${JAVA_HOME:-/Applications/Android Studio.app/Contents/jbr/Contents/Home}
ANDROID_HOME=${ANDROID_HOME:-$HOME/Library/Android/sdk}
export JAVA_HOME
TASK_PLATFORM=${TASK_PLATFORM:-android-37.0}
TASK_TOOLS=${TASK_TOOLS:-36.0.0}
TASK_ANDROID="$ANDROID_HOME/platforms/$TASK_PLATFORM/android.jar"
TASK_BIN="$ANDROID_HOME/build-tools/$TASK_TOOLS"
TASK_BUILD="$TASK_ROOT/.local-build"
TASK_KEYS="$TASK_ROOT/.local-signing/debug.keystore"
TASK_APK="$TASK_ROOT/../静读-1.1.apk"
mkdir -p "$TASK_BUILD/classes" "$TASK_BUILD/generated" "$TASK_BUILD/dex" "$TASK_ROOT/.local-signing"
"$JAVA_HOME/bin/java" -version
test -f "$TASK_ANDROID"
"$TASK_BIN/aapt2" compile --dir "$TASK_ROOT/app/src/main/res" -o "$TASK_BUILD/resources.zip"
python3 - "$TASK_ROOT" "$TASK_BUILD" <<'PY'
import sys
from pathlib import Path
root, build = map(Path, sys.argv[1:])
source = (root/'app/src/main/AndroidManifest.xml').read_text()
(build/'AndroidManifest.xml').write_text(source.replace('<manifest xmlns:', '<manifest package="cn.local.quietreader" xmlns:'))
PY
"$TASK_BIN/aapt2" link -o "$TASK_BUILD/base.apk" -I "$TASK_ANDROID" \
    --manifest "$TASK_BUILD/AndroidManifest.xml" --min-sdk-version 26 --target-sdk-version 35 \
    --version-code 2 --version-name 1.1 --java "$TASK_BUILD/generated" "$TASK_BUILD/resources.zip"
"$JAVA_HOME/bin/javac" --release 17 -encoding UTF-8 -classpath "$TASK_ANDROID" \
    -d "$TASK_BUILD/classes" "$TASK_ROOT"/app/src/main/java/cn/local/quietreader/*.java \
    "$TASK_BUILD/generated/cn/local/quietreader/R.java"
"$JAVA_HOME/bin/jar" cf "$TASK_BUILD/classes.jar" -C "$TASK_BUILD/classes" .
"$TASK_BIN/d8" --lib "$TASK_ANDROID" --min-api 26 --output "$TASK_BUILD/dex" "$TASK_BUILD/classes.jar"
python3 - "$TASK_BUILD" <<'PY'
import sys
from pathlib import Path
from zipfile import ZipFile, ZIP_STORED
build = Path(sys.argv[1])
with ZipFile(build/'base.apk', 'a', compression=ZIP_STORED) as z:
    for dex in (build/'dex').glob('*.dex'):
        z.write(dex, dex.name)
PY
if [ ! -f "$TASK_KEYS" ]; then
    "$JAVA_HOME/bin/keytool" -genkeypair -keystore "$TASK_KEYS" -storepass android -keypass android \
        -alias androiddebugkey -dname 'CN=QuietReader Personal Debug,O=Local,C=CN' \
        -keyalg RSA -keysize 2048 -validity 10000 -storetype PKCS12
    chmod 600 "$TASK_KEYS"
fi
"$TASK_BIN/zipalign" -f -p 4 "$TASK_BUILD/base.apk" "$TASK_BUILD/aligned.apk"
"$TASK_BIN/apksigner" sign --ks "$TASK_KEYS" --ks-pass pass:android --key-pass pass:android \
    --ks-key-alias androiddebugkey --out "$TASK_APK" "$TASK_BUILD/aligned.apk"
"$TASK_BIN/apksigner" verify --verbose "$TASK_APK"
"$TASK_BIN/zipalign" -c -p 4 "$TASK_APK"
echo "APK: $TASK_APK"
