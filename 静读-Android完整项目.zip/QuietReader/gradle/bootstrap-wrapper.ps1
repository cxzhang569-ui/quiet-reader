$ErrorActionPreference = 'Stop'
$jar = Join-Path $PSScriptRoot 'wrapper/gradle-wrapper.jar'
$expected = '2db75c40782f5e8ba1fc278a5574bab070adccb2d21ca5a6e5ed840888448046'
if (!(Test-Path $jar)) {
    $temp = "$jar.$([guid]::NewGuid()).tmp"
    try {
        Invoke-WebRequest -UseBasicParsing -Uri 'https://raw.githubusercontent.com/gradle/gradle/v8.11.1/gradle/wrapper/gradle-wrapper.jar' -OutFile $temp
        if ((Get-FileHash $temp -Algorithm SHA256).Hash.ToLower() -ne $expected) { throw 'Wrapper checksum mismatch' }
        Move-Item $temp $jar
    } finally { if (Test-Path $temp) { Remove-Item $temp } }
}
if ((Get-FileHash $jar -Algorithm SHA256).Hash.ToLower() -ne $expected) { throw 'Wrapper checksum mismatch' }
