@echo off
setlocal
set "APP_HOME=%~dp0"
if defined JAVA_HOME (set "JAVA_CMD=%JAVA_HOME%\bin\java.exe") else (set "JAVA_CMD=java.exe")
"%JAVA_CMD%" -version >nul 2>&1
if errorlevel 1 (echo Requires JDK 17 or newer. See README.md. & exit /b 1)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%APP_HOME%gradle\bootstrap-wrapper.ps1"
if errorlevel 1 exit /b 1
"%JAVA_CMD%" -classpath "%APP_HOME%gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
