package cn.local.quietreader;

import org.w3c.dom.*;
import org.xml.sax.InputSource;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.*;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;

/** ZIPs are never extracted. Every resource stays inside a validated archive. */
public final class EpubBook {
    public static final long MAX_IMPORT = 100L * 1024 * 1024;
    private static final int MAX_ENTRY = 16 * 1024 * 1024;
    private static final long MAX_EXPANDED = 256L * 1024 * 1024;
    public final File file;
    public final String id, title;
    public final List<Chapter> chapters;
    private final Map<String, String> media;

    public static final class Chapter {
        public final String path, label;
        Chapter(String path, String label) { this.path = path; this.label = label; }
    }

    private EpubBook(File file, String id, String title, List<Chapter> chapters,
                     Map<String, String> media) {
        this.file = file; this.id = id; this.title = title;
        this.chapters = Collections.unmodifiableList(chapters); this.media = media;
    }

    public static void validateArchive(File file) throws IOException {
        if (file.length() > MAX_IMPORT) throw new IOException("书籍超过 100 MB 限制");
        long expanded = 0;
        int count = 0;
        Set<String> seen = new HashSet<>();
        try (ZipFile zip = new ZipFile(file)) {
            Enumeration<? extends ZipEntry> entries = zip.entries();
            byte[] buffer = new byte[32768];
            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();
                if (++count > 4000) throw new IOException("书籍包含过多文件");
                if (entry.isDirectory()) continue;
                String path = entry.getName();
                if (!isSafePath(path) || !seen.add(path)) throw new IOException("EPUB 包含无效或重复路径");
                long size = 0;
                CRC32 crc = new CRC32();
                try (InputStream in = zip.getInputStream(entry)) {
                    int n;
                    while ((n = in.read(buffer)) != -1) {
                        size += n; expanded += n; crc.update(buffer, 0, n);
                        if (size > MAX_ENTRY || expanded > MAX_EXPANDED)
                            throw new IOException("书籍解压后过大，已停止导入");
                    }
                }
                if (entry.getCrc() != -1 && entry.getCrc() != crc.getValue())
                    throw new IOException("EPUB 文件损坏（校验失败）");
            }
        }
    }

    public static EpubBook open(File file, String id) throws Exception {
        try (ZipFile zip = new ZipFile(file)) {
            if (!"application/epub+zip".equals(new String(read(zip, "mimetype"), StandardCharsets.US_ASCII).trim()))
                throw new IOException("这不是有效的 EPUB 文件");
            if (zip.getEntry("META-INF/encryption.xml") != null)
                throw new IOException("暂不支持带 DRM、加密资源或混淆字体的 EPUB，请使用无加密版本");
            Document container = xml(read(zip, "META-INF/container.xml"));
            NodeList roots = container.getElementsByTagNameNS("*", "rootfile");
            if (roots.getLength() == 0) throw new IOException("EPUB 缺少内容描述文件");
            String opf = resolve("root", ((Element) roots.item(0)).getAttribute("full-path"));
            if (!isSafePath(opf)) throw new IOException("EPUB 内容路径无效");
            Document pkg = xml(read(zip, opf));
            NodeList metadata = pkg.getElementsByTagNameNS("*", "title");
            String title = metadata.getLength() == 0 ? "未命名书籍" : metadata.item(0).getTextContent().trim();
            if (title.isEmpty()) title = "未命名书籍";
            if (title.length() > 300) title = title.substring(0, 300);
            Map<String, String> paths = new HashMap<>(), media = new HashMap<>(), labels = new HashMap<>();
            String navPath = null, ncxPath = null;
            NodeList items = pkg.getElementsByTagNameNS("*", "item");
            for (int i = 0; i < items.getLength(); i++) {
                Element item = (Element) items.item(i);
                String path = resolve(opf, item.getAttribute("href"));
                paths.put(item.getAttribute("id"), path);
                media.put(path, item.getAttribute("media-type"));
                if (Arrays.asList(item.getAttribute("properties").split("\\s+")).contains("nav")) navPath = path;
                if ("application/x-dtbncx+xml".equals(item.getAttribute("media-type"))) ncxPath = path;
            }
            // TOC supplies names; spine is always the authoritative reading order.
            try {
                if (ncxPath != null) {
                    Document toc = xml(read(zip, ncxPath));
                    NodeList points = toc.getElementsByTagNameNS("*", "navPoint");
                    for (int i = 0; i < points.getLength(); i++) {
                        Element point = (Element) points.item(i);
                        NodeList content = point.getElementsByTagNameNS("*", "content");
                        NodeList text = point.getElementsByTagNameNS("*", "text");
                        if (content.getLength() > 0 && text.getLength() > 0)
                            labels.putIfAbsent(resolve(ncxPath, ((Element)content.item(0)).getAttribute("src")), text.item(0).getTextContent().trim());
                    }
                }
                if (navPath != null) {
                    Document toc = xml(read(zip, navPath));
                    NodeList navs = toc.getElementsByTagNameNS("*", "nav");
                    for (int n = 0; n < navs.getLength(); n++) {
                        Element nav = (Element)navs.item(n);
                        String type = nav.getAttributeNS("http://www.idpf.org/2007/ops", "type");
                        if (!Arrays.asList(type.split("\\s+")).contains("toc")) continue;
                        NodeList links = nav.getElementsByTagNameNS("*", "a");
                        for (int i = 0; i < links.getLength(); i++) {
                            Element link = (Element) links.item(i);
                            labels.putIfAbsent(resolve(navPath, link.getAttribute("href")), link.getTextContent().trim());
                        }
                    }
                }
            } catch (Exception ignored) { /* A malformed optional TOC must not block the spine. */ }
            NodeList refs = pkg.getElementsByTagNameNS("*", "itemref");
            List<Chapter> chapters = new ArrayList<>();
            for (int i = 0; i < refs.getLength(); i++) {
                Element ref = (Element) refs.item(i);
                if ("no".equals(ref.getAttribute("linear"))) continue;
                String path = paths.get(ref.getAttribute("idref"));
                if (path == null || zip.getEntry(path) == null) throw new IOException("EPUB 缺少正文文件");
                String mime = media.get(path);
                if (!"application/xhtml+xml".equals(mime) && !"text/html".equals(mime))
                    throw new IOException("暂不支持此书的正文格式：" + mime);
                String label = labels.get(path);
                if (label == null || label.isEmpty()) label = "第 " + (chapters.size() + 1) + " 节";
                if (label.length() > 200) label = label.substring(0, 200);
                chapters.add(new Chapter(path, label));
            }
            if (chapters.isEmpty()) throw new IOException("EPUB 没有可阅读的正文");
            NodeList metas = pkg.getElementsByTagNameNS("*", "meta");
            for (int i = 0; i < metas.getLength(); i++) {
                Element m = (Element)metas.item(i);
                if (("rendition:layout".equals(m.getAttribute("property")) && "pre-paginated".equals(m.getTextContent().trim()))
                    || ("fixed-layout".equals(m.getAttribute("name")) && "true".equals(m.getAttribute("content"))))
                    throw new IOException("暂不支持固定版式 EPUB，请使用可重排版文本书籍");
            }
            return new EpubBook(file, id, title, chapters, media);
        }
    }

    public byte[] read(String path) throws IOException {
        try (ZipFile zip = new ZipFile(file)) { return read(zip, path); }
    }
    public String mime(String path) {
        String declared = media.get(path);
        if (declared != null) return declared;
        String p = path.toLowerCase(Locale.ROOT);
        if (p.endsWith(".css")) return "text/css";
        if (p.endsWith(".png")) return "image/png";
        if (p.endsWith(".jpg") || p.endsWith(".jpeg")) return "image/jpeg";
        if (p.endsWith(".gif")) return "image/gif";
        if (p.endsWith(".svg")) return "image/svg+xml";
        if (p.endsWith(".webp")) return "image/webp";
        if (p.endsWith(".woff2")) return "font/woff2";
        if (p.endsWith(".woff")) return "font/woff";
        if (p.endsWith(".ttf")) return "font/ttf";
        return "application/octet-stream";
    }
    public int chapterIndex(String path) {
        for (int i = 0; i < chapters.size(); i++) if (chapters.get(i).path.equals(path)) return i;
        return -1;
    }
    static boolean isSafePath(String path) {
        if (path == null || path.isEmpty() || path.startsWith("/") || path.contains("\\") || path.indexOf('\0') >= 0) return false;
        for (String part : path.split("/")) if (part.equals("..") || part.equals(".")) return false;
        return !path.contains(":");
    }
    static String resolve(String base, String href) throws IOException {
        try {
            URI u = new URI(null, null, "/" + base, null).resolve(new URI(href.replace(" ", "%20"))).normalize();
            if (u.isAbsolute() || u.getAuthority() != null) throw new IOException("EPUB 引用了外部资源");
            String path = u.getPath();
            if (path == null || !path.startsWith("/")) throw new IOException("无效路径");
            path = path.substring(1);
            if (!isSafePath(path)) throw new IOException("无效路径");
            return path;
        } catch (java.net.URISyntaxException e) { throw new IOException("EPUB 资源路径格式错误", e); }
    }
    private static byte[] read(ZipFile zip, String path) throws IOException {
        if (!isSafePath(path)) throw new IOException("无效资源路径");
        ZipEntry entry = zip.getEntry(path);
        if (entry == null || entry.isDirectory()) throw new IOException("缺少 EPUB 资源：" + path);
        if (entry.getSize() > MAX_ENTRY) throw new IOException("单个资源超过 16 MB");
        try (InputStream in = zip.getInputStream(entry); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[16384]; int n;
            while ((n = in.read(buffer)) != -1) {
                if (out.size() + n > MAX_ENTRY) throw new IOException("资源过大");
                out.write(buffer, 0, n);
            }
            return out.toByteArray();
        }
    }
    private static Document xml(byte[] bytes) throws Exception {
        if (bytes.length > 2 * 1024 * 1024) throw new IOException("EPUB 元数据过大");
        // Android's DOM factory does not implement every desktop JAXP feature.
        // Normalize supported XML encodings and reject internal DTDs BEFORE parsing.
        String source;
        if (bytes.length >= 2 && ((bytes[0] == (byte)0xFF && bytes[1] == (byte)0xFE)
            || (bytes[0] == (byte)0xFE && bytes[1] == (byte)0xFF))) source = new String(bytes, StandardCharsets.UTF_16);
        else if (bytes.length >= 4 && bytes[0] == 0 && bytes[1] == '<') source = new String(bytes, StandardCharsets.UTF_16BE);
        else if (bytes.length >= 4 && bytes[0] == '<' && bytes[1] == 0) source = new String(bytes, StandardCharsets.UTF_16LE);
        else source = new String(bytes, StandardCharsets.UTF_8);
        if (source.startsWith("\uFEFF")) source = source.substring(1);
        if (source.indexOf('\0') >= 0) throw new IOException("不支持此 XML 编码");
        java.util.regex.Pattern dtd = java.util.regex.Pattern.compile("(?is)<!DOCTYPE[^>]*>");
        java.util.regex.Matcher matcher = dtd.matcher(source);
        while (matcher.find()) if (matcher.group().contains("["))
            throw new IOException("不支持含自定义 XML 实体的书籍");
        if (source.toUpperCase(Locale.ROOT).contains("<!ENTITY"))
            throw new IOException("不支持自定义 XML 实体");
        source = matcher.replaceAll(""); // Simple external EPUB2 DOCTYPEs are unnecessary.
        DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
        f.setNamespaceAware(true);
        f.setExpandEntityReferences(false);
        DocumentBuilder b = f.newDocumentBuilder();
        b.setEntityResolver((publicId, systemId) -> new InputSource(new StringReader("")));
        Document doc = b.parse(new InputSource(new StringReader(source)));
        return doc;
    }
}
