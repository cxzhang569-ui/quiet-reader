package cn.local.quietreader;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.*;

public final class MainActivity extends Activity {
    private static final int OPEN_BOOK = 100;
    private static final String HOST = "epub.invalid";
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private android.content.SharedPreferences prefs;
    private volatile EpubBook book;
    private ReaderView web;
    private LinearLayout root;
    private TextView heading, status;
    private Button previous, next;
    private int chapter, fontSize, generation;
    private boolean dark, busy, loading, restoring, library = true;
    private double position;
    private String fragment;
    private final Runnable saveLater = () -> savePosition(false);
    private int background() { return Color.parseColor(dark ? "#171C1B" : "#F6F3EB"); }
    private int foreground() { return Color.parseColor(dark ? "#DCE3DD" : "#263C35"); }
    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    private File booksDir() { File dir = new File(getFilesDir(), "books"); dir.mkdirs(); return dir; }

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        prefs = getSharedPreferences("reader", MODE_PRIVATE);
        fontSize = prefs.getInt("fontSize", 20);
        dark = prefs.getBoolean("dark", false);
        // Android 15+ edge-to-edge: inset the entire native reader, including its controls.
        getWindow().setStatusBarColor(background());
        getWindow().setNavigationBarColor(background());
        String last = prefs.getString("lastBook", "");
        boolean resume = prefs.getBoolean("resumeReader", false);
        showLibrary();
        if (!last.isEmpty() && resume) openSaved(last);
    }

    private TextView text(String value, int size) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size);
        t.setTextColor(foreground()); t.setPadding(dp(8), dp(6), dp(8), dp(6));
        return t;
    }
    private Button button(String value, Runnable action) {
        Button b = new Button(this); b.setText(value); b.setTextSize(14);
        b.setTextColor(foreground()); b.setAllCaps(false); b.setMinWidth(0); b.setMinimumWidth(0);
        b.setMinHeight(dp(48)); b.setOnClickListener(v -> action.run());
        return b;
    }
    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL); return r;
    }
    private void addEven(LinearLayout r, View v) { r.addView(v, new LinearLayout.LayoutParams(0, -2, 1)); }
    private void baseLayout() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(background());
        root.setPadding(dp(10), dp(4), dp(10), dp(4));
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            v.setPadding(dp(10) + insets.getSystemWindowInsetLeft(), dp(4) + insets.getSystemWindowInsetTop(),
                dp(10) + insets.getSystemWindowInsetRight(), dp(4) + insets.getSystemWindowInsetBottom());
            return insets.consumeSystemWindowInsets();
        });
        int flags = dark ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        getWindow().getDecorView().setSystemUiVisibility(flags);
        setContentView(root); root.requestApplyInsets();
    }

    private void showLibrary() {
        savePosition(true);
        destroyReader(); library = true;
        prefs.edit().putBoolean("resumeReader", false).apply();
        baseLayout();
        LinearLayout top = row();
        TextView logo = text("静读", 30); top.addView(logo, new LinearLayout.LayoutParams(0, -2, 1));
        top.addView(button(dark ? "浅色" : "深色", () -> { dark = !dark; persistSettings(); showLibrary(); }));
        root.addView(top);
        root.addView(text("一本书，一段安静的时间。", 16));
        root.addView(button("＋ 打开本地 EPUB", this::pickBook));
        status = text(busy ? "正在检查并导入，请稍候…" : "完全离线 · 无账号 · 数据仅保存在本机", 13);
        root.addView(status);
        ScrollView scroll = new ScrollView(this);
        LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(0, dp(16), 0, 0); scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        File[] files = booksDir().listFiles((dir, name) -> name.matches("[a-f0-9]{64}\\.epub"));
        if (files == null || files.length == 0) {
            list.addView(text("书架还是空的", 23));
            list.addView(text("点击上方按钮，在系统文件选择器中选择手机里的 .epub 文件。\n\n导入后会保存本地副本，下次打开自动回到上次位置。\n\n支持 Android 8.0 及以上版本、无加密的可重排版 EPUB 2 / 3。", 16));
        } else {
            Arrays.sort(files, (a, b) -> Long.compare(prefs.getLong(idOf(b) + ".time", 0), prefs.getLong(idOf(a) + ".time", 0)));
            list.addView(text("最近阅读", 18));
            for (File file : files) {
                String id = idOf(file);
                LinearLayout item = row();
                Button open = button(prefs.getString(id + ".title", "未命名书籍") + "\n继续阅读", () -> openSaved(id));
                open.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
                item.addView(open, new LinearLayout.LayoutParams(0, -2, 1));
                Button remove = button("删除", () -> confirmDelete(id));
                remove.setContentDescription("删除 " + prefs.getString(id + ".title", "书籍"));
                item.addView(remove); list.addView(item);
            }
        }
        root.addView(text("阅读时可上下滚动，或左右滑动／点击按钮翻页。", 12));
    }
    private static String idOf(File file) { return file.getName().replace(".epub", ""); }
    private void confirmDelete(String id) {
        if (busy) { toast("正在导入，请稍候"); return; }
        new AlertDialog.Builder(this).setTitle("从静读删除？")
            .setMessage("删除应用内副本和阅读进度，手机里的原始 EPUB 文件不受影响。")
            .setNegativeButton("取消", null).setPositiveButton("删除", (d, w) -> {
                File f = new File(booksDir(), id + ".epub");
                if (f.exists() && !f.delete()) { toast("删除失败，请重试"); return; }
                android.content.SharedPreferences.Editor e = prefs.edit();
                for (String key : prefs.getAll().keySet()) if (key.startsWith(id + ".")) e.remove(key);
                if (id.equals(prefs.getString("lastBook", ""))) e.remove("lastBook");
                e.apply(); if (book != null && book.id.equals(id)) book = null; showLibrary();
            }).show();
    }
    private void pickBook() {
        if (busy) { toast("正在处理书籍，请稍候"); return; }
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        // Some Android document providers mislabel EPUB as ZIP/octet-stream. Validate its contents ourselves.
        intent.setType("*/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivityForResult(intent, OPEN_BOOK); }
        catch (ActivityNotFoundException e) { error("没有找到系统文件选择器"); }
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == OPEN_BOOK && result == RESULT_OK && data != null && data.getData() != null)
            importBook(data.getData());
    }
    private void importBook(Uri uri) {
        if (busy) return;
        busy = true; if (status != null) status.setText("正在检查并导入，请稍候…");
        worker.execute(() -> {
            File temp = null;
            try {
                temp = File.createTempFile("import-", ".tmp", booksDir());
                MessageDigest digest = MessageDigest.getInstance("SHA-256");
                try (InputStream in = getContentResolver().openInputStream(uri); OutputStream out = new FileOutputStream(temp)) {
                    if (in == null) throw new IOException("无法读取此文件");
                    byte[] buffer = new byte[32768]; int n; long size = 0;
                    while ((n = in.read(buffer)) != -1) {
                        size += n;
                        if (size > EpubBook.MAX_IMPORT) throw new IOException("书籍超过 100 MB 限制");
                        if (Thread.currentThread().isInterrupted()) throw new IOException("导入已取消");
                        digest.update(buffer, 0, n); out.write(buffer, 0, n);
                    }
                }
                StringBuilder hash = new StringBuilder();
                for (byte b : digest.digest()) hash.append(String.format(Locale.ROOT, "%02x", b & 255));
                String id = hash.toString();
                EpubBook.validateArchive(temp);
                EpubBook.open(temp, id); // Validate before installing a private copy.
                File target = new File(booksDir(), id + ".epub");
                if (!target.exists() && !temp.renameTo(target)) throw new IOException("无法保存书籍，请检查可用空间");
                EpubBook opened = EpubBook.open(target, id);
                runOnUiThread(() -> { busy = false; if (!isDestroyed()) activate(opened); });
            } catch (Exception e) {
                runOnUiThread(() -> { busy = false; if (!isDestroyed()) { showLibrary(); error(message(e)); } });
            } finally { if (temp != null && temp.exists()) temp.delete(); }
        });
    }
    private void openSaved(String id) {
        if (busy || !id.matches("[a-f0-9]{64}")) return;
        busy = true; status.setText("正在打开书籍…");
        worker.execute(() -> {
            try {
                EpubBook opened = EpubBook.open(new File(booksDir(), id + ".epub"), id);
                runOnUiThread(() -> { busy = false; if (!isDestroyed()) activate(opened); });
            } catch (Exception e) {
                runOnUiThread(() -> { busy = false; if (!isDestroyed()) { showLibrary(); error(message(e)); } });
            }
        });
    }
    private void activate(EpubBook opened) {
        savePosition(true); destroyReader();
        book = opened; library = false;
        chapter = Math.max(0, Math.min(opened.chapters.size() - 1, prefs.getInt(opened.id + ".chapter", 0)));
        position = clamp(prefs.getFloat(opened.id + ".position", 0));
        prefs.edit().putString(opened.id + ".title", opened.title)
            .putLong(opened.id + ".time", System.currentTimeMillis()).putString("lastBook", opened.id)
            .putBoolean("resumeReader", true).apply();
        baseLayout();
        LinearLayout top = row(); top.addView(button("书架", this::showLibrary));
        heading = text(opened.title, 17); heading.setMaxLines(2);
        top.addView(heading, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(top);
        LinearLayout settings = row();
        addEven(settings, button("章节", this::showChapters));
        addEven(settings, button("字号 −", () -> changeFont(-2)));
        addEven(settings, button("字号 ＋", () -> changeFont(2)));
        addEven(settings, button(dark ? "浅色" : "深色", this::toggleTheme));
        root.addView(settings);
        web = new ReaderView(); configureWeb();
        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));
        status = text("", 12); status.setGravity(Gravity.CENTER); root.addView(status);
        LinearLayout bottom = row();
        previous = button("← 上一页", () -> turn(-1)); next = button("下一页 →", () -> turn(1));
        addEven(bottom, previous); addEven(bottom, next); root.addView(bottom);
        loadChapter(chapter, position, null);
    }
    private void showChapters() {
        if (loading) return;
        String[] names = new String[book.chapters.size()];
        for (int i = 0; i < names.length; i++) names[i] = (i + 1) + ". " + book.chapters.get(i).label;
        new AlertDialog.Builder(this).setTitle("章节列表").setSingleChoiceItems(names, chapter, (d, n) -> {
            savePosition(true); d.dismiss(); loadChapter(n, 0, null);
        }).setNegativeButton("关闭", null).show();
    }
    private void changeFont(int delta) {
        if (loading || restoring) return;
        int changed = Math.max(14, Math.min(36, fontSize + delta));
        if (changed == fontSize) { toast("字号范围为 14–36"); return; }
        savePosition(true); fontSize = changed; persistSettings();
        loadChapter(chapter, position, null); toast("字号 " + fontSize);
    }
    private void toggleTheme() {
        if (loading || restoring) return;
        savePosition(true); dark = !dark; persistSettings();
        EpubBook current = book; activate(current);
    }
    private void persistSettings() { prefs.edit().putBoolean("dark", dark).putInt("fontSize", fontSize).apply(); }
    private void configureWeb() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(false); s.setDomStorageEnabled(false); s.setDatabaseEnabled(false);
        s.setAllowFileAccess(false); s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false); s.setAllowUniversalAccessFromFileURLs(false);
        s.setBlockNetworkLoads(true); s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSupportZoom(false); s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false);
        s.setDefaultTextEncodingName("UTF-8"); s.setTextZoom(100);
        web.setBackgroundColor(background()); web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        CookieManager.getInstance().setAcceptCookie(false);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, false);
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                EpubBook current = book;
                if (current == null || !"https".equals(u.getScheme()) || !HOST.equals(u.getHost())
                    || u.getPort() != -1 || !"GET".equals(request.getMethod())) return denied();
                String prefix = "/" + current.id + "/";
                String path = u.getPath();
                if (path == null || !path.startsWith(prefix)) return denied();
                path = path.substring(prefix.length());
                if (!EpubBook.isSafePath(path)) return denied();
                try {
                    String mime = current.mime(path);
                    boolean html = mime.equals("application/xhtml+xml") || mime.equals("text/html");
                    if (html && (!request.isForMainFrame() || current.chapterIndex(path) < 0)) return denied();
                    byte[] bytes = current.read(path);
                    if (html) { bytes = readerHtml(bytes).getBytes(StandardCharsets.UTF_8); mime = "text/html"; }
                    Map<String, String> headers = new HashMap<>();
                    headers.put("Cache-Control", "no-store");
                    headers.put("X-Content-Type-Options", "nosniff");
                    headers.put("Content-Security-Policy", "default-src 'none'; img-src https://" + HOST
                        + " data:; style-src 'unsafe-inline' https://" + HOST
                        + "; font-src https://" + HOST + " data:; script-src 'none'; frame-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'");
                    return new WebResourceResponse(mime, (html || mime.startsWith("text/")) ? "UTF-8" : null,
                        200, "OK", headers, new ByteArrayInputStream(bytes));
                } catch (Exception e) { return denied(); }
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (library || book == null || web != view || !request.isForMainFrame()) return true;
                Uri u = request.getUrl();
                String prefix = "/" + book.id + "/";
                if ("https".equals(u.getScheme()) && HOST.equals(u.getHost()) && u.getPort() == -1
                    && u.getPath() != null && u.getPath().startsWith(prefix)) {
                    int target = book.chapterIndex(u.getPath().substring(prefix.length()));
                    if (target >= 0) {
                        if (target == chapter && u.getFragment() != null) return false;
                        if (!loading && !restoring) { savePosition(true); loadChapter(target, 0, u.getFragment()); }
                        return true;
                    }
                }
                toast("离线模式：不打开外部链接"); return true;
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (library || web != view || !loading || !url.equals(chapterUrl())) return;
                loading = false; restoring = true;
                final int token = generation;
                settlePosition(token, 0, -1);
            }
            @Override public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse response) {
                if (request.isForMainFrame() && !library && web == view) {
                    loading = restoring = false;
                    status.setText("章节资源不可读取，请返回书架重新打开");
                }
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError e) {
                if (request.isForMainFrame() && !library && web == view) {
                    loading = restoring = false; status.setText("章节加载失败，请返回书架重试");
                }
            }
        });
    }
    private static WebResourceResponse denied() {
        return new WebResourceResponse("text/plain", "UTF-8", 403, "Blocked", Collections.emptyMap(),
            new ByteArrayInputStream(new byte[0]));
    }
    private String readerHtml(byte[] bytes) {
        String html;
        if (bytes.length >= 2 && ((bytes[0] == (byte)0xFF && bytes[1] == (byte)0xFE)
            || (bytes[0] == (byte)0xFE && bytes[1] == (byte)0xFF))) html = new String(bytes, StandardCharsets.UTF_16);
        else if (bytes.length >= 4 && bytes[0] == 0 && bytes[1] == '<') html = new String(bytes, StandardCharsets.UTF_16BE);
        else if (bytes.length >= 4 && bytes[0] == '<' && bytes[1] == 0) html = new String(bytes, StandardCharsets.UTF_16LE);
        else html = new String(bytes, StandardCharsets.UTF_8);
        if (html.startsWith("\uFEFF")) html = html.substring(1);
        String bg = dark ? "#171c1b" : "#f6f3eb", fg = dark ? "#dce3dd" : "#263c35";
        String extra = "<meta name='viewport' content='width=device-width, initial-scale=1'>"
            + "<style>html{font-size:" + fontSize + "px!important;background:" + bg + "!important;}"
            + "html body{margin:0!important;padding:22px 14px 36px!important;box-sizing:border-box!important;"
            + "width:auto!important;max-width:48rem!important;margin-inline:auto!important;"
            + "font-size:1rem!important;line-height:1.85!important;writing-mode:horizontal-tb!important;}"
            + "html body,html body *{color:" + fg + "!important;background-color:transparent!important;"
            + "font-size:inherit!important;line-height:inherit!important;overflow-wrap:anywhere!important;"
            + "max-width:100%!important;box-sizing:border-box!important;}"
            + "html body h1,html body h2{font-size:1.35em!important;line-height:1.5!important;}"
            + "html body p{margin-block:0.7em!important;}"
            + "html body img,html body svg{max-width:100%!important;height:auto!important;}"
            + "html body pre{white-space:pre-wrap!important;}html body a{text-decoration:underline!important;}"
            + "html body iframe,html body object,html body embed,html body form{display:none!important;}"
            + "</style>";
        // Put reader style at the end of the head so ordinary publisher styles are overridden.
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(?i)</head\\s*>").matcher(html);
        if (m.find()) return html.substring(0, m.start()) + extra + html.substring(m.start());
        return "<!doctype html><html><head>" + extra + "</head><body>" + html + "</body></html>";
    }
    private String chapterUrl() {
        String path = Uri.encode(book.chapters.get(chapter).path, "/");
        return "https://" + HOST + "/" + book.id + "/" + path;
    }
    private void loadChapter(int index, double ratio, String anchor) {
        handler.removeCallbacks(saveLater);
        generation++; chapter = index; position = clamp(ratio); fragment = anchor;
        loading = true; restoring = true;
        previous.setEnabled(false); next.setEnabled(false);
        status.setText("正在排版…");
        savePosition(true); // Saves the pending target, never the old WebView scroll offset.
        web.loadUrl(chapterUrl());
    }
    private void settlePosition(int token, int attempt, int oldRange) {
        if (token != generation || library || web == null || !restoring) return;
        int range = web.range();
        web.scrollTo(0, (int)Math.round(position * range));
        if ((attempt >= 2 && range == oldRange) || attempt >= 12) {
            restoring = false;
            if (fragment != null && !fragment.isEmpty()) {
                String anchor = fragment; fragment = null;
                web.loadUrl(chapterUrl() + "#" + Uri.encode(anchor));
            }
            previous.setEnabled(true); next.setEnabled(true); updateStatus();
        } else handler.postDelayed(() -> settlePosition(token, attempt + 1, range), 150);
    }
    private void turn(int direction) {
        if (library || loading || restoring) return;
        int y = web.getScrollY(), range = web.range();
        if (direction > 0 && y >= range - dp(2)) {
            if (chapter + 1 < book.chapters.size()) { savePosition(true); loadChapter(chapter + 1, 0, null); }
            else toast("已到全书末尾");
        } else if (direction < 0 && y <= dp(2)) {
            if (chapter > 0) { savePosition(true); loadChapter(chapter - 1, 1, null); }
            else toast("已到全书开头");
        } else {
            int step = Math.max(dp(40), Math.round(web.getHeight() * 0.88f));
            web.scrollTo(0, Math.max(0, Math.min(range, y + direction * step)));
            savePosition(false); updateStatus();
        }
    }
    private void updateStatus() {
        if (book == null || library || loading) return;
        status.setText((chapter + 1) + "/" + book.chapters.size() + " 节 · "
            + book.chapters.get(chapter).label + " · 本节 " + Math.round(position * 100) + "%");
        status.setContentDescription("阅读位置，章节 " + (chapter + 1) + "，本节百分之 " + Math.round(position * 100));
    }
    private static double clamp(double n) { return Double.isNaN(n) ? 0 : Math.max(0, Math.min(1, n)); }
    private void savePosition(boolean sync) {
        if (book == null || library) return;
        if (web != null && !loading && !restoring) position = web.range() == 0 ? 0 : clamp((double)web.getScrollY() / web.range());
        android.content.SharedPreferences.Editor e = prefs.edit()
            .putInt(book.id + ".chapter", chapter).putFloat(book.id + ".position", (float)position);
        if (sync) e.commit(); else e.apply();
    }
    private void destroyReader() {
        generation++; handler.removeCallbacks(saveLater);
        if (web != null) {
            if (web.getParent() instanceof android.view.ViewGroup) ((android.view.ViewGroup)web.getParent()).removeView(web);
            web.stopLoading(); web.destroy(); web = null;
        }
        loading = restoring = false;
    }
    @Override protected void onPause() { savePosition(true); super.onPause(); }
    @Override protected void onSaveInstanceState(Bundle out) { savePosition(true); super.onSaveInstanceState(out); }
    @Override protected void onDestroy() { savePosition(true); destroyReader(); worker.shutdownNow(); super.onDestroy(); }
    @Override public void onBackPressed() { if (!library) showLibrary(); else super.onBackPressed(); }
    private void toast(String value) { Toast.makeText(this, value, Toast.LENGTH_SHORT).show(); }
    private void error(String value) { new AlertDialog.Builder(this).setTitle("无法打开书籍").setMessage(value).setPositiveButton("知道了", null).show(); }
    private static String message(Exception e) {
        if (e instanceof FileNotFoundException) return "文件不存在或没有读取权限，请重新选择本地 EPUB。";
        if (e instanceof java.util.zip.ZipException) return "文件不是 EPUB，或 EPUB 已损坏。";
        return e.getMessage() == null ? "无法解析此 EPUB，请确认文件完整且未加密。" : e.getMessage();
    }
    private final class ReaderView extends WebView {
        private float downX, downY;
        ReaderView() { super(MainActivity.this); }
        int range() { return Math.max(0, computeVerticalScrollRange() - computeVerticalScrollExtent()); }
        @Override protected void onScrollChanged(int x, int y, int oldX, int oldY) {
            super.onScrollChanged(x, y, oldX, oldY);
            if (library || loading || restoring) return;
            position = range() == 0 ? 0 : clamp((double)y / range());
            updateStatus(); handler.removeCallbacks(saveLater); handler.postDelayed(saveLater, 250);
        }
        @Override public boolean onTouchEvent(android.view.MotionEvent e) {
            if (loading || restoring) return true;
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN) { downX = e.getX(); downY = e.getY(); }
            if (e.getActionMasked() == MotionEvent.ACTION_UP) {
                float dx = e.getX() - downX, dy = e.getY() - downY;
                if (Math.abs(dx) > dp(80) && Math.abs(dx) > Math.abs(dy) * 1.6f) {
                    MotionEvent cancel = MotionEvent.obtain(e); cancel.setAction(MotionEvent.ACTION_CANCEL);
                    super.onTouchEvent(cancel); cancel.recycle(); turn(dx < 0 ? 1 : -1); return true;
                }
            }
            return super.onTouchEvent(e);
        }
    }
}
