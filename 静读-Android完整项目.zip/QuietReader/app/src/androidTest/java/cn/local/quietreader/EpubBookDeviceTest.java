package cn.local.quietreader;

import android.test.AndroidTestCase;
import java.io.File;

/** Also exercises Android's own XML/ZIP implementations, without third-party libraries. */
@SuppressWarnings("deprecation")
public final class EpubBookDeviceTest extends AndroidTestCase {
    public void testProductionParser() throws Exception {
        File dir = new File(getContext().getCacheDir(), "parser-checks");
        assertEquals(16, ParserChecks.run(dir));
        dir.delete();
    }
}
