package cn.local.quietreader;
import android.app.*;
import android.content.*;
import android.graphics.*;
import android.os.*;
import android.test.InstrumentationTestCase;
import android.view.*;
import android.webkit.WebView;
import java.io.*;
import java.lang.reflect.*;
/** Run on a dedicated emulator. Restores reader preferences after the test. */
public class ReaderGestureTest extends InstrumentationTestCase {
 java.util.Map<String,?> originalPrefs;
 @Override protected void tearDown() throws Exception {
  try {
   if (activity != null) ui(() -> activity.finish());
   Context c=getInstrumentation().getTargetContext();
   if(originalPrefs!=null){
    android.content.SharedPreferences.Editor e=c.getSharedPreferences("reader",0).edit().clear();
    for(java.util.Map.Entry<String,?> entry:originalPrefs.entrySet()){
     String k=entry.getKey();Object v=entry.getValue();
     if(v instanceof String)e.putString(k,(String)v);
     else if(v instanceof Integer)e.putInt(k,(Integer)v);
     else if(v instanceof Long)e.putLong(k,(Long)v);
     else if(v instanceof Float)e.putFloat(k,(Float)v);
     else if(v instanceof Boolean)e.putBoolean(k,(Boolean)v);
    }
    e.commit();
   }
   new File(new File(c.getFilesDir(),"books"),id+".epub").delete();
  } finally {super.tearDown();}
 }
 MainActivity activity; WebView web; Object pages; final String id="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
 interface Job { void run() throws Exception; }
 void ui(Job r) throws Exception { final Exception[] err={null}; getInstrumentation().runOnMainSync(()->{try{r.run();}catch(Exception e){err[0]=e;}}); if(err[0]!=null)throw err[0]; }
 Object field(Object o,String name)throws Exception{Field f=o.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(o);}
 void invoke(String name,Class<?>[] types,Object...args)throws Exception{Method m=MainActivity.class.getDeclaredMethod(name,types);m.setAccessible(true);m.invoke(activity,args);}
 void waitReady()throws Exception{for(int i=0;i<100;i++){final boolean[] busy={true};ui(()->busy[0]=(boolean)field(activity,"loading")||(boolean)field(activity,"restoring")||(boolean)field(pages,"active"));if(!busy[0])return;Thread.sleep(100);}fail("Reader did not settle");}
 int x()throws Exception{final int[] r={0};ui(()->r[0]=web.getScrollX());return r[0];}
 void event(long t,int action,float x,float y){MotionEvent e=MotionEvent.obtain(t,SystemClock.uptimeMillis(),action,x,y,0);getInstrumentation().sendPointerSync(e);e.recycle();}
 void gesture(float fraction,boolean cancel)throws Exception{
  int[] loc=new int[2]; final int[] size=new int[2];ui(()->{web.getLocationOnScreen(loc);size[0]=web.getWidth();size[1]=web.getHeight();});
  float start=loc[0]+size[0]*(fraction < 0 ? .2f : .8f),y=loc[1]+size[1]*.5f;long t=SystemClock.uptimeMillis();event(t,0,start,y);
  for(int i=1;i<=8;i++){event(t,2,start-size[0]*fraction*i/8,y);Thread.sleep(50);}
  Thread.sleep(150);
  if(!cancel){Bitmap shot=getInstrumentation().getUiAutomation().takeScreenshot();try(FileOutputStream out=new FileOutputStream(new File(getInstrumentation().getTargetContext().getExternalFilesDir(null),"drag.png"))){shot.compress(Bitmap.CompressFormat.PNG,100,out);}shot.recycle();}
  event(t,cancel?3:1,start-size[0]*fraction,y);waitReady();
 }
 void shot(String name)throws Exception{Bitmap b=getInstrumentation().getUiAutomation().takeScreenshot();try(FileOutputStream out=new FileOutputStream(new File(getInstrumentation().getTargetContext().getExternalFilesDir(null),name+".png"))){b.compress(Bitmap.CompressFormat.PNG,100,out);}b.recycle();}
 public void testCoverPaging()throws Exception{
  Context c=getInstrumentation().getTargetContext();File dir=new File(c.getFilesDir(),"books");dir.mkdirs();File book=new File(dir,id+".epub");
  try(InputStream in=getInstrumentation().getContext().getAssets().open("gesture.epub");OutputStream out=new FileOutputStream(book)){byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))!=-1)out.write(buffer,0,n);}
  originalPrefs=c.getSharedPreferences("reader",0).getAll();
  c.getSharedPreferences("reader",0).edit().clear().commit();
  Intent intent=new Intent(c,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);activity=(MainActivity)getInstrumentation().startActivitySync(intent);
  ui(()->invoke("activate",new Class[]{EpubBook.class},EpubBook.open(book,id)));
  web=(WebView)field(activity,"web");pages=field(activity,"pages"); waitReady();
  assertEquals(0,x()); int width=web.getWidth(); shot("first");
  gesture(.15f,true); assertEquals("Cancelled drag must preserve page",0,x());
  gesture(.12f,false); assertEquals("Short slow drag must spring back",0,x());
  gesture(.55f,false);assertEquals("Forward swipe must advance one page",width,x()); shot("second");
  gesture(-.55f,true);assertEquals("Cancelled backward drag",width,x());
  gesture(-.55f,false);assertEquals("Backward swipe",0,x());
  ui(()->invoke("turn",new Class[]{int.class},1));waitReady();
  ui(()->invoke("turn",new Class[]{int.class},-1));waitReady(); assertEquals("Previous button returns to first page",0,x());
  ui(()->invoke("loadChapter",new Class[]{int.class,double.class,String.class},0,1.0,null));waitReady();
  gesture(.12f,false); assertEquals("Cancel across chapter",0,(int)field(activity,"chapter"));
  ui(()->invoke("turn",new Class[]{int.class},1));waitReady(); assertEquals("Cross chapter",1,(int)field(activity,"chapter"));assertEquals(0,x());
  ui(()->invoke("turn",new Class[]{int.class},-1));waitReady();assertEquals(0,(int)field(activity,"chapter"));assertTrue(x()>width);
  int last=x(); ui(()->invoke("savePosition",new Class[]{boolean.class},true));
  assertTrue(c.getSharedPreferences("reader",0).getFloat(id+".position",0)>.99f);
  ui(()->invoke("changeFont",new Class[]{int.class},2));waitReady();assertTrue(x()>0);
  ui(()->invoke("toggleTheme",new Class[]{}));web=(WebView)field(activity,"web");pages=field(activity,"pages");waitReady();
  assertTrue((boolean)field(activity,"dark"));assertTrue(x()>0);shot("dark");
  ui(()->activity.finish());
  activity=(MainActivity)getInstrumentation().startActivitySync(intent);
  for(int i=0;i<100 && field(activity,"web")==null;i++)Thread.sleep(100);
  web=(WebView)field(activity,"web");pages=field(activity,"pages");assertNotNull(web);waitReady();
  assertTrue("Theme survives reopening",(boolean)field(activity,"dark"));
  assertTrue("Position survives reopening",x()>0);assertEquals(0,(int)field(activity,"chapter"));
  ui(()->activity.finish());
 }
}
