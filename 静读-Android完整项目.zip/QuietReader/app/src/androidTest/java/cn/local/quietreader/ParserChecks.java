package cn.local.quietreader;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;

/** Tests the actual production parser, on a desktop JDK or Android device. */
public final class ParserChecks {
    private static int passed;
    private static void check(boolean result, String name) {
        if (!result) throw new AssertionError(name);
        passed++; System.out.println("PASS " + name);
    }
    private static LinkedHashMap<String, byte[]> fixture() {
        LinkedHashMap<String, byte[]> m = new LinkedHashMap<>();
        put(m, "mimetype", "application/epub+zip");
        put(m, "META-INF/container.xml", "<container xmlns='urn:oasis:names:tc:opendocument:xmlns:container'><rootfiles><rootfile full-path='OPS/book.opf'/></rootfiles></container>");
        put(m, "OPS/book.opf", "<package xmlns='http://www.idpf.org/2007/opf' version='3.0'><metadata xmlns:dc='http://purl.org/dc/elements/1.1/'><dc:title>离线测试</dc:title></metadata><manifest><item id='two' href='Text/第二章.xhtml' media-type='application/xhtml+xml'/><item id='one' href='Text/one.xhtml' media-type='application/xhtml+xml'/><item id='nav' href='nav.xhtml' media-type='application/xhtml+xml' properties='nav'/></manifest><spine><itemref idref='one'/><itemref idref='two'/></spine></package>");
        put(m, "OPS/Text/one.xhtml", "<html xmlns='http://www.w3.org/1999/xhtml'><body>第一章</body></html>");
        put(m, "OPS/Text/第二章.xhtml", "<html xmlns='http://www.w3.org/1999/xhtml'><body>第二章</body></html>");
        put(m, "OPS/nav.xhtml", "<html xmlns='http://www.w3.org/1999/xhtml' xmlns:epub='http://www.idpf.org/2007/ops'><body><nav epub:type='toc'><a href='Text/one.xhtml'>开篇</a><a href='Text/%E7%AC%AC%E4%BA%8C%E7%AB%A0.xhtml#end'>终章</a></nav></body></html>");
        return m;
    }
    private static void put(Map<String, byte[]> m, String path, String value) { m.put(path, value.getBytes(StandardCharsets.UTF_8)); }
    private static File write(File dir, Map<String, byte[]> entries) throws IOException {
        File f = File.createTempFile("test-", ".epub", dir);
        try (ZipOutputStream z = new ZipOutputStream(new FileOutputStream(f))) {
            for (Map.Entry<String, byte[]> e : entries.entrySet()) {
                z.putNextEntry(new ZipEntry(e.getKey())); z.write(e.getValue()); z.closeEntry();
            }
        }
        return f;
    }
    private static void rejects(File dir, Map<String, byte[]> data, String name) throws Exception {
        File f = write(dir, data); boolean rejected = false;
        try { EpubBook.validateArchive(f); EpubBook.open(f, "test"); }
        catch (Exception expected) { rejected = true; }
        finally { f.delete(); }
        check(rejected, name);
    }
    public static int run(File dir) throws Exception {
        passed = 0; dir.mkdirs();
        File f = write(dir, fixture());
        try {
            EpubBook.validateArchive(f); EpubBook b = EpubBook.open(f, "test");
            check(b.title.equals("离线测试"), "EPUB3 Chinese metadata");
            check(b.chapters.size() == 2 && b.chapters.get(0).path.endsWith("one.xhtml"), "spine order beats manifest order");
            check(b.chapters.get(1).label.equals("终章"), "EPUB3 TOC and percent-encoded paths");
            check(new String(b.read("OPS/Text/第二章.xhtml"), StandardCharsets.UTF_8).contains("第二章"), "Unicode ZIP resource");
        } finally { f.delete(); }
        check(EpubBook.resolve("OPS/Text/one.xhtml", "../images/a%20b.png#x").equals("OPS/images/a b.png"), "relative resource resolution");
        check(!EpubBook.isSafePath("../secret") && !EpubBook.isSafePath("/absolute") && !EpubBook.isSafePath("C:\\secret"), "unsafe path guard");
        boolean external = false;
        try { EpubBook.resolve("OPS/a.xhtml", "https://example.org/a"); } catch (IOException expected) { external = true; }
        check(external, "reject external manifest URL");
        LinkedHashMap<String, byte[]> m = fixture(); m.remove("OPS/nav.xhtml");
        String opf = new String(m.get("OPS/book.opf"), StandardCharsets.UTF_8).replace("properties='nav'", "")
            .replace("</manifest>", "<item id='ncx' href='toc.ncx' media-type='application/x-dtbncx+xml'/></manifest>");
        put(m, "OPS/book.opf", opf);
        put(m, "OPS/toc.ncx", "<!DOCTYPE ncx PUBLIC '-//NISO//DTD ncx 2005-1//EN' 'http://www.daisy.org/z3986/2005/ncx-2005-1.dtd'><ncx xmlns='http://www.daisy.org/z3986/2005/ncx/'><navMap><navPoint><navLabel><text>EPUB2 目录</text></navLabel><content src='Text/one.xhtml'/></navPoint></navMap></ncx>");
        f = write(dir, m);
        try { check(EpubBook.open(f, "test").chapters.get(0).label.equals("EPUB2 目录"), "EPUB2 NCX with external DOCTYPE offline"); } finally { f.delete(); }
        m = fixture(); m.put("OPS/book.opf", new String(m.get("OPS/book.opf"), StandardCharsets.UTF_8).getBytes(StandardCharsets.UTF_16));
        f = write(dir, m);
        try { check(EpubBook.open(f, "test").title.equals("离线测试"), "UTF16 metadata"); } finally { f.delete(); }
        m = fixture(); put(m, "mimetype", "text/plain"); rejects(dir, m, "reject non-EPUB ZIP");
        m = fixture(); m.remove("OPS/Text/one.xhtml"); rejects(dir, m, "reject missing spine file");
        m = fixture(); put(m, "../escape.txt", "bad"); rejects(dir, m, "reject ZIP traversal");
        m = fixture(); put(m, "META-INF/encryption.xml", "<encryption/>"); rejects(dir, m, "reject encryption");
        m = fixture(); put(m, "OPS/book.opf", "<!DOCTYPE package [<!ENTITY x SYSTEM 'file:///etc/passwd'>]><package>&x;</package>"); rejects(dir, m, "reject XML entity before parsing");
        m = fixture(); opf = new String(m.get("OPS/book.opf"), StandardCharsets.UTF_8).replace("</metadata>", "<meta property='rendition:layout'>pre-paginated</meta></metadata>");
        put(m, "OPS/book.opf", opf); rejects(dir, m, "reject fixed layout explicitly");
        m = fixture(); m.put("OPS/huge.bin", new byte[16 * 1024 * 1024 + 1]); rejects(dir, m, "reject compressed resource bomb");
        return passed;
    }
    public static void main(String[] args) throws Exception {
        File dir = Files.createTempDirectory("quietreader-checks-").toFile();
        try { System.out.println("Passed: " + run(dir)); } finally { dir.delete(); }
    }
}
