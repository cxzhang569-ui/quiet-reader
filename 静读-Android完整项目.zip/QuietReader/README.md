# 静读 QuietReader

个人使用的 Android 离线 EPUB 阅读器。项目已实现，已使用本机官方 Android SDK 编译并生成 **`../静读-1.1.apk`**（Android 8.0 及以上）。APK 签名与对齐校验通过，桌面及 Android 模拟器解析器 16 项行为测试均通过，模拟器安装及跟手翻页、回弹、跨章节、字号、深色和重开进度测试通过；手机上的最终验收仍需执行。详细验证状态见 [VALIDATION.md](VALIDATION.md)。

## 已实现的功能

- 系统文件选择器打开 EPUB；文件选择器允许显示所有文件，以兼容把 EPUB 标成 ZIP 的手机，导入时检查真实内容。
- 导入为应用私有副本，按 SHA-256 去重；书架显示最近阅读，支持删除副本与进度。
- 按 EPUB spine 顺序阅读，支持 EPUB 3 导航目录和 EPUB 2 NCX 的章节名称。
- 左右跟手覆盖式翻页：当前页随手指滑动，露出下一页并显示页边阴影；短滑回弹，长滑或快速滑动完成翻页。按钮使用同一动画，章节首尾自动衔接。正文按屏幕高度分页。
- 字号 14–36、浅色／深色模式，全局记忆设置。
- 每本书独立记忆章节和章内分页比例。回到桌面、返回书架、旋转屏幕或下次启动可恢复；更改字号后的定位为相近位置，并非逐字精确书签。
- 显示本节进度；无账号、广告、统计、服务器和网络功能。

## 技术选择

使用 **Java 17 + Android 原生界面 + 系统 WebView**，支持 Android 8.0（API 26）以上。

这是一个单人使用、功能聚焦的应用：系统提供文件选择器、网页排版、私有存储和设置保存，不需要跨平台框架或额外阅读 SDK。原生代码负责翻页与进度，WebView 仅排版正文，JavaScript 全部关闭，没有原生脚本桥接，也没有第三方运行时依赖。

EPUB 是 ZIP 容器：解析 container.xml → OPF manifest/spine → XHTML 正文，ZIP 内资源通过 WebView 请求拦截提供。`epub.invalid` 只是内部资源标识，应用没有启动 HTTP 服务，也不连接这个域名。

## 当前电脑直接重新打包（无需额外下载）

本机 Android Studio Rabbit 自带 JDK 25，已安装 SDK Platform 37.0 和 Build-Tools 36.0.0。当前网络无法连接 Gradle Wrapper 下载地址，因此提供已验证的官方 SDK 直接构建入口：

```sh
./build-local.sh
```

需要 Python 3 和上述已安装工具；脚本使用 AAPT2、javac（Java 17 字节码）、D8、zipalign、apksigner，生成上一级目录的 `静读-1.1.apk`。应用仍以 Android 8.0 为最低版本、Android 15 为目标版本。

签名保存在 `.local-signing/debug.keystore`，请在本机保留并备份。该个人调试密钥使用公开的调试口令 `android`，只用于个人安装；源码 ZIP 不包含密钥。后续更新应使用同一密钥以覆盖安装、保留书架和进度。Gradle 默认调试密钥与此密钥不同，请勿混用；若切换构建方式，需让 Gradle 使用此密钥。

## 在 Android Studio 编译并安装

### 1. 准备工具

安装 [Android Studio](https://developer.android.com/studio)，在 SDK Manager 中安装：

- Android SDK Platform 35
- Android SDK Build-Tools 35.0.0
- Android SDK Platform-Tools（USB 安装时使用）

项目固定 AGP 8.9.2、Gradle 8.11.1，使用 JDK 17 或 21（本机新版本 Studio 内置 JDK 25，不能直接运行该版本 Gradle）。版本依据：[Android 官方兼容表](https://developer.android.com/build/releases/agp-8-9-0-release-notes)。

**构建工具首次配置需要电脑联网下载；安装后的阅读器完全离线。**

### 2. 初始化构建启动文件

当前交付环境无法下载二进制文件，因此不包含 `gradle-wrapper.jar`。项目附带的 `gradlew` / `gradlew.bat` 首次运行会下载 Gradle 官方启动文件，并校验已固定的 SHA-256；之后按标准 Wrapper 流程构建。为避免不同 Android Studio 对缺失 JAR 的处理差异，建议首次导入前执行一次：

macOS（先在终端进入解压后的 QuietReader 文件夹）：

```sh
export JAVA_HOME="/Applications/Android Studio.app/Contents/jbr/Contents/Home"
./gradlew --version
```

Windows（在项目文件夹打开命令提示符，路径按实际安装位置调整）：

```bat
set "JAVA_HOME=C:\Program Files\Android\Android Studio\jbr"
gradlew.bat --version
```

如果 GitHub 无法连接，可在可访问网络上从 [Gradle 官方仓库](https://github.com/gradle/gradle/blob/v8.11.1/gradle/wrapper/gradle-wrapper.jar) 下载原始文件，放到 `gradle/wrapper/gradle-wrapper.jar`，然后重试。校验值必须为：

```text
2db75c40782f5e8ba1fc278a5574bab070adccb2d21ca5a6e5ed840888448046
```

校验来源：[Gradle 官方校验表](https://gradle.org/release-checksums/)。Gradle 发行包也设置了固定校验值。

### 3. 打开并编译项目

在 Android Studio 点击 **Open**，选择包含 `settings.gradle` 的 `QuietReader` 文件夹，等待 Gradle Sync 完成。Gradle JDK 选择 JDK 17 或 21；如果提示 SDK 位置，选择 SDK Manager 所显示的路径（Android Studio 会写入本机 `local.properties`，无需修改项目源码）。

点击菜单 **Build → Build App Bundle(s) / APK(s) → Build APK(s)**（不同版本可能显示 Generate APKs），或在 Android Studio 终端执行：

```sh
./gradlew assembleDebug
```

Windows 使用 `gradlew.bat assembleDebug`。

成功后 APK 位于：

```text
app/build/outputs/apk/debug/app-debug.apk
```

Debug APK 会由 Android 构建工具自动创建的调试密钥签名，个人安装无需准备商店账号或发布签名。保留同一台电脑的调试密钥，后续版本可覆盖安装并保留数据；若密钥更换，Android 会拒绝覆盖安装。

### 4. 安装到你的手机

两种任选：

1. 用数据线连接手机，在手机开发者选项中打开 USB 调试并同意电脑连接，Android Studio 选择该设备后点击 **Run ▶**。
2. 将 `app-debug.apk` 复制到手机，使用文件管理器打开。系统提示时允许该文件管理器“安装未知应用”，安装后即可关闭这项允许。

也可以在配置好 Platform-Tools 后执行：

```sh
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

无需上架应用商店。USB 调试只是电脑安装时的操作，阅读器本身不申请权限。

## 首次体验

把 `samples/静读体验.epub` 复制到手机。打开“静读”，点击“打开本地 EPUB”，在“下载”或本地文件夹选择它。示例为本项目原创，含三章中文、长正文、CSS、SVG 插图和跨章节链接。

系统选择器也可能显示云盘提供方；完全离线使用时请选择已经保存在手机里的文件。导入成功后不再依赖原文件或文件提供方，原文件移动／删除也不影响应用内副本。

## 隐私和安全边界

- 主 Manifest **没有任何权限声明**，包括 INTERNET、READ_EXTERNAL_STORAGE 和 MANAGE_EXTERNAL_STORAGE；仅通过系统选择器读取用户选中的文件。
- 书籍和阅读设置在 Android 应用私有目录；关闭系统云备份并设置 Android 12+ 数据迁移排除规则。卸载应用或清除应用数据会删除所有导入副本和进度，原始书籍保留。
- 不持久保存文件提供方授权，不保存原 URI，不请求整盘或目录访问权限。
- 禁用 JavaScript、Cookie、DOM 存储、文件 URL、content URL、混合内容、网络加载；不添加 JavaScript 接口。
- 仅响应当前书籍 ZIP 内的允许路径，外部链接不交给其他应用打开；CSP 进一步限制脚本、表单、嵌套页面及外部资源。
- ZIP 从不解压到文件系统；限制导入大小 100 MB、单项解压大小 16 MB、总解压大小 256 MB、条目数 4000，检查 CRC、重复路径与越界路径。
- 元数据解析在进入 XML 解析器之前拒绝内部 DTD／自定义实体，移除简单外部 DOCTYPE，禁止外部实体解析。

## 支持范围和限制

适合普通无加密、可重排版 EPUB 2 / 3 小说与文本书籍，支持本地 CSS 和常见图片。暂不支持 DRM、混淆字体（含 `META-INF/encryption.xml` 会明确拒绝）、固定版式、音视频、竖排、脚本交互、PDF、MOBI、全文搜索、高亮、云同步。目录按 spine 章节列出，暂不展示章内小节的完整层级。

系统 WebView 版本会影响排版，请使用手机可用的系统更新。尚未做复杂出版社样式或不同厂商真机兼容测试。夜间阅读样式会覆盖正文文字和背景，但不会反转插图颜色。

## 验证

有 JDK 后，可独立测试实际 EPUB 解析器，不需要 Android SDK：

```sh
./tests/run-parser-tests.sh
```

预期 16 项通过。覆盖 EPUB 2/3、顺序、目录、中文路径、UTF-16、资源、异常包、加密、实体和压缩包限制。测试编译的是应用实际使用的 `EpubBook.java`。

连接 Android 手机或启动模拟器后：

```sh
./gradlew connectedDebugAndroidTest
```

这会通过 Android 自带的传统测试运行器，对 Android 自己的 XML / ZIP 实现重复上述解析器检查；没有下载额外测试框架。测试代码不打包进阅读器 APK。另有 ReaderGestureTest 使用本地生成的测试 EPUB，检查跟手翻页、回弹、跨章节和重开进度；应在专用模拟器执行，测试结束会恢复阅读器设置。运行时和界面仍需按 [手机验收清单](ACCEPTANCE.md) 检查。

## 项目文件

- `app/src/main/java/cn/local/quietreader/MainActivity.java`：界面、文件导入、书架、主题、翻页和进度保存。
- `app/src/main/java/cn/local/quietreader/EpubBook.java`：ZIP 限制、元数据、spine / TOC 和资源读取。
- `app/src/main/AndroidManifest.xml`：无权限声明的应用入口。
- `tests/`、`app/src/androidTest/`：电脑和 Android 解析器测试。
- `samples/`：原创体验 EPUB。
