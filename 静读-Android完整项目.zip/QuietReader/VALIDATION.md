# 验证状态（2026-10-14）

## 已实际执行

- 桌面 JVM：运行生产 EPUB 解析器的 16 项行为测试，全部通过。
- Android 37.0 ARM64 模拟器：运行 EpubBookDeviceTest，内部执行同一套 16 项检查，解析器与翻页测试一起运行，结果 `OK (2 tests)`。
- 官方 SDK 构建：AAPT2 资源编译与链接、javac 全部应用源码编译（Java 17 字节码）、D8 转换、zipalign 对齐、apksigner 签名全部成功。
- APK 验证：v2、v3 签名通过，对齐检查通过；包名 cn.local.quietreader、版本 1.1（versionCode 2）、最低 API 26、目标 API 35，无权限声明。
- 模拟器安装 APK 返回 `Success`；启动 MainActivity 返回 `Status: ok`，进程存在，Activity 为前台 resumed 状态。
- 本轮重新执行 16 项静态检查通过：XML 结构、隐私配置、文件选择器、无脚本桥、示例 EPUB 完整性、固定下载校验值等。

## 构建环境与方式

本机安装了 Android Studio Rabbit 1、内置 JDK 25、SDK Platform 37.0、Build-Tools 36.0.0。`build-local.sh` 可离线重复生成上一级目录的 `静读-1.1.apk`。

Gradle 官方 Wrapper 下载地址在当前命令环境连接重置，且项目 Gradle 8.11.1 不能使用 JDK 25 运行，因此本次使用已安装的 SDK 官方工具直接构建。Android Studio 已打开项目，但没有完成或宣称完成 Gradle Sync、Gradle assemble 或 Android Lint。标准 Gradle 构建需要可用网络、JDK 17/21 和 Platform 35，详见 README。

签名密钥保存在 `.local-signing/debug.keystore`，不放入源码 ZIP。保留该密钥才能给本次 APK 覆盖更新。已核对 1.0 / 1.1 的签名证书 SHA-256 相同，可覆盖安装。

## 仍需手机验收

本轮已在 Android 37.0 ARM64 模拟器执行真实触摸事件和按钮测试：前后翻页、短滑回弹、系统取消、反向取消、跨章节完成与取消、字号重排、深色切换，以及关闭并重新打开后的主题与进度恢复。已查看首屏、下一页、拖动中途与深色截图；首屏第 1–4 段接到下一页第 5 段，内容连续。

参考效果为左右覆盖式翻页；页面快照仅在内存中用于动画，未添加网络权限、脚本执行或第三方依赖。

尚未在用户手机验证系统文件选择器、实际书籍排版、翻页/滑动、深色模式、字号和进度恢复；请按 ACCEPTANCE.md 测试。DRM、固定版式 EPUB 不支持。
